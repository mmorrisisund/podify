const cookie = require('cookie')
const jwt = require('jsonwebtoken')
const { createClient } = require('../utils/db-helpers')
const publicKey = require('./publickey')

exports.handler = async function (event) {
  const cookies = event.headers.cookie && cookie.parse(event.headers.cookie)

  if (!cookies?.jwt) {
    return {
      statusCode: 401,
      body: JSON.stringify({ msg: 'Unauthorized access' })
    }
  }

  try {
    const payload = jwt.verify(cookies.jwt, publicKey)
    const dbClient = createClient()
    const user = await dbClient.usersCollection({ id: payload.userId })

    if (!user) {
      return {
        statusCode: 404,
        body: JSON.stringify({ msg: 'User not found' })
      }
    }
    console.log(user)
    return {
      statusCode: 200,
      body: JSON.stringify({ msg: 'success' })
    }
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ msg: error.message })
    }
  }
}
